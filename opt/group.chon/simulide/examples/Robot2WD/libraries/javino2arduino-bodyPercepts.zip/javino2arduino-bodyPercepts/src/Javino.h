/*
  Javino.h - Library communication for Arduino and Jason.

  Created by Lazarin, NM and Pantoja, CE - January 29, 2015.
  nilson.lazarin@cefet-rj.br
	carlos.pantoja@cefet-rj.br

  Updated in 2025-01-24
*/

#ifndef Javino_h
#define Javino_h

#include "Arduino.h"
#include "../lib/StdCpp/map"

class Javino
{
  public:
    void start(int baudRate);
    void sendMsg(String msg);
    String getMsg();
    boolean availableMsg();
    boolean requestPercepts();
    boolean requestAction(String strCommand);
    void readSerial();
    void addPercept(String newPercept);
    void addInteroception(String newPercept);
    void addExteroception(String newPercept);
    void addProprioception(String newPercept);
    void clearPercepts();
    void sendPercepts();
    std::map<String, void(*)()> act;
    void run();
    typedef void (*PerceiveCallback)();
    void perceive(PerceiveCallback callback);
  private:
    unsigned int _round;
    unsigned int _size;
    boolean  _msg;
    String _finalymsg;
    String _sizeMSG;
    String _percepts;
    unsigned long _time;
    PerceiveCallback callback;
};

#endif