/*
  Javino.cpp - Library communication for Arduino and Jason.

  Created by Lazarin, NM and Pantoja, CE - January 29, 2015.
	nilson.lazarin@cefet-rj.br
	carlos.pantoja@cefet-rj.br

  Updated in 2025-01-24
*/

#include "Arduino.h"
#include "Javino.h"

void Javino::start(int baudRate){
  _finalymsg.reserve(255);
  _sizeMSG = "";
  _finalymsg = "";
  _percepts = "";
  _msg = false;
  _size = 0;
  _round = 0;
  _time = 0;
  Serial.begin(baudRate);
}

void Javino::run(){
  if(availableMsg()){
    if(requestPercepts()){
      callback();
      sendPercepts();
    }
    else{
      Javino::act[getMsg()]();
    } 
  }
}

boolean Javino::requestAction(String strCommand){
   if(getMsg() == strCommand){
     return true;
   }else{
     return false;
   }
}

boolean Javino::requestPercepts(){
  if(getMsg() == "getPercepts"){
    return true;
  }else{
    return false;
  }  
}

void Javino::perceive(PerceiveCallback funcao){
  callback = funcao;
}

void Javino::addPercept(String newPercept){
  _percepts = _percepts+newPercept+";"; 
}

void Javino::addInteroception(String newPercept){
  addPercept(newPercept+"[i]"); 
}

void Javino::addExteroception(String newPercept){
  addPercept(newPercept+"[e]"); 
}

void Javino::addProprioception(String newPercept){
  addPercept(newPercept+"[p]"); 
}

void Javino::sendPercepts(){
  sendMsg(_percepts);
  clearPercepts();
}

void Javino::clearPercepts(){
  _percepts = ""; 
}

void Javino::sendMsg(String m){
  char buffer[3];
  snprintf(buffer, sizeof(buffer), "%02X", m.length()); 
  String sizeofMSG = buffer; 
	Serial.print("fffe"+sizeofMSG+m);
}

String Javino::getMsg(){
  return _finalymsg;
}

boolean Javino::availableMsg(){
  boolean isMsg = _msg;
  _msg=false;
	return isMsg;
}

void Javino::readSerial() {
  while (Serial.available()){
    if(_round==0){
      _time = millis();
      _finalymsg = "";
    }else if((_round>0) && (_time+300<millis())){
      _sizeMSG = "";
      _round=0;
      _size = 0;
      _finalymsg = "";
      _msg = false;
      _time = millis();
    }
    
    char inChar = (char)Serial.read();
    _round++;
    
    if(((_round==1 | _round==2 | _round==3) && inChar!='f') | (_round==4 && inChar!='e')){
      _round=0;
      _size = 0;
      _finalymsg = "";
      _sizeMSG = "";
      _msg = false;
    }else if(_round==5 | _round==6 ){
      _msg = false;
      _sizeMSG += inChar;
      if(_round==6){
        _size = (strtol(_sizeMSG.c_str(), NULL, 16))+6;
        _sizeMSG = "";
      }
    }else if(_round>6){
      if(_round<_size){
        _msg = false;
        _finalymsg += inChar;
      }else if (_round=_size){
        _finalymsg += inChar;
        _round=0;
        _size = 0;
        _msg = true;
      }
    }
  }
}